Overleaf: New Project > Upload Project > select this zip. Compiler: pdfLaTeX. Main file: main.tex.
Class: IEEEtran (conference, two-column). Bibliography: IEEEtran.bst (numeric). Overleaf already has both.
Figures 2-5 are low-resolution drafts: replace the files in figures/ with your 300-dpi PNGs (same names).
If your conference supplies its own template, paste the text sections into it.
